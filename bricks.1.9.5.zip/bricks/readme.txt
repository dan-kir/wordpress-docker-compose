=== Bricks - Visual Website Builder for WordPress ===
Requires at least: 4.6
Tested up to: 6.0
Requires PHP: 5.4
Stable tag: 5.4
License: GPLv2
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Official Documentation: https://academy.bricksbuilder.io/
Getting Started: https://academy.bricksbuilder.io/topic/getting-started/
Developer Docs: https://academy.bricksbuilder.io/collection/developer/
Get in touch: https://bricksbuilder.io/contact/
