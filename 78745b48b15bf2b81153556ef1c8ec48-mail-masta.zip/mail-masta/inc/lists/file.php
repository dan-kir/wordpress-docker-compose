<?php 
echo $_POST['path'];
?>